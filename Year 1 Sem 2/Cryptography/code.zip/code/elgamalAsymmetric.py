import random


def gcd(a, b):
    if a < b:
        return gcd(b, a)
    elif a % b == 0:
        return b
    else:
        return gcd(b, a % b)


# Generating large random numbers
def gen_key(q):
    key = random.randint(pow(10, 20), q)
    while gcd(q, key) != 1:
        key = random.randint(pow(10, 20), q)

    return key


# Modular exponentiation
def power(a, b, c):

    return pow(a, b, c)


# Asymmetric encryption
def encrypt(msg, q, h, g):
    en_msg = []

    k = gen_key(q)  # Alice selects a number such that gcd(k, q) = 1
    s = power(h, k, q)
    p = power(g, k, q)

    for i in range(0, len(msg)):
        en_msg.append(msg[i])

    for i in range(0, len(en_msg)):
        en_msg[i] = s * ord(en_msg[i])

    return en_msg, p


def decrypt(en_msg, p, key, q):
    dr_msg = []
    h = power(p, key, q)
    for i in range(0, len(en_msg)):
        dr_msg.append(chr(int(en_msg[i] / h)))

    return dr_msg


msg = input("Enter message to encrypt: ")
# Bob generates keys
q = random.randint(pow(10, 20), pow(10, 50))
g = random.randint(2, q)

key = gen_key(q)  # Bob's private key
h = power(g, key, q)  # Bob's public key

# Alice encrypts  message with Bob's public key
en_msg, p = encrypt(msg, q, h, g)
print("Ciphertext:", en_msg)

# Alice sends ciphertext to Bob
# Bob decrypts ciphertext
dr_msg = decrypt(en_msg, p, key, q)
dmsg = ''.join(dr_msg)
print("Decrypted Message:", dmsg)


# reference: https://www.geeksforgeeks.org/elgamal-encryption-algorithm/
