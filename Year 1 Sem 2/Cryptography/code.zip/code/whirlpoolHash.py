# need to install whirlpool library/package first
import whirlpool


def hashMsg(pt):
    newWP = whirlpool.new(pt.encode('utf-8'))
    md = newWP.hexdigest()

    return md


message = input('Enter the message to hash: ')
md = hashMsg(message)

print(f"The hashed value is \n{md}")


# reference: https://www.geeksforgeeks.org/whirlpool-hash-function-in-python/
